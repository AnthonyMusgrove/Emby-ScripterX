
/* ScripterX Telegram Bot Notification Package */

var telegram_bot_token = "";
var telegram_chat_id = "";
var telegram_api_url = "https://api.telegram.org/bot";

function _package_init() {
	/* Log output to Emby Log */
	ScripterX.Log.Info("ScripterX Telegram Notifications Package Initialised.");

	telegram_bot_token = ScripterX.Config.Get("BOTTOKEN").StringValue();
	telegram_chat_id = ScripterX.Config.Get("CHATID").StringValue();
	
	ScripterX.Log.Info("SX Telegram Notify Bot Token = " + telegram_bot_token + ", Chat ID = " + telegram_chat_id);
	
	sendNotification("ScripterX Notification Plugin Active!");

}

function sendNotification(notification_msg)
{
	var submit_notification_url = telegram_api_url + telegram_bot_token + "/sendmessage?chat_id=" + telegram_chat_id + "&text=" + notification_msg;
	ScripterX.Web.Post(submit_notification_url, null);
}

/*
* Events available:  (handled with function _EventName())
* onAuthenticationFailed, onAuthenticationSuccess, onLibraryScanComplete, onMediaItemAdded, onMediaItemRemoved, onMediaItemUpdated,
* onPlaybackStart, onPlaybackStopped, onScheduledTask, onSessionEnded, onSessionStarted, onCameraImageUploaded, onLiveTVRecordingStart,
* onLiveTVRecordingEnded, onScheduledTaskStart, onScheduledTaskEnded,  onMediaItemAddedComplete, onPlaybackProgress
*/

/*  Tokens available in context _onPlaybackStart :
%playback.position.ticks%,%playback.item.total.ticks%,%playback.position.percentage%,%item.id%,%item.name%,%item.path%,%item.originaltitle%,%item.tagline%,%item.overview%,%location.type%,%item.type%,%item.productionyear%,%item.isvirtual%,%item.meta.*%,%item.library.type%,%item.library.name%,%season.id%,%season.name%,%season.number%,%season.meta.*%,%series.id%,%series.name%,%series.meta.*%,%episode.number%,%user.id%,%username%,%device.id%,%device.name%,%server.id%,%server.name%,%server.port.local.http%,%server.port.local.https%,%server.port.public.http%,%server.port.public.https%,%server.version%,%server.platform.os%,%server.platform.osver%,%server.platform.uptime%,%scripterx.version%,%scripterx.version.major%,%scripterx.version.revision%,%scripterx.version.minor%,%scripterx.version.build%
*/

